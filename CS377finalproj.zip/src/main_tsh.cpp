#include <tsh.h>

using namespace std;

int main() {
  char cmd[81];
  char *cmdTokens[25];
  char* pipeChar = "|";
  bool findPipeChar = strchr(cmd, *pipeChar) != nullptr;
  simple_shell *shell = new simple_shell();
  cout << "tsh> ";
  while (fgets(cmd, sizeof(cmd), stdin)) {
    if (cmd[0] != '\n' && cmd[0] != '|' && !findPipeChar) {
      shell->parse_command(cmd, cmdTokens);
      if (shell->isQuit(*cmdTokens)) {
        exit(0);
      } else {
        shell->exec_command(cmdTokens);
      }
    } else if (findPipeChar) {
      shell->piping_commands(cmdTokens, cmd, cmdTokens);
      if (shell->isQuit(*cmdTokens)) {
        exit(0);
      } else {
        shell->exec_command(cmdTokens);
      }
    }
    cout << "tsh> ";
  }
  cout << endl;
  exit(0);
}
