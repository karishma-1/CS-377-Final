#include <tsh.h>
#include <iostream>
#include <sys/wait.h>

using namespace std;

void simple_shell::piping_commands(char** argv, char* cmd, char** cmdTokens) {
    int i = 0;
    int filedes[2]; // contains space for 0, 1, and -1 --> file descriptors
    while (argv[i] != NULL) {
        parse_command(cmd, cmdTokens); // includes | for pipes
        exec_piping_command(argv, filedes); 
        i++;
    }
}

void simple_shell::exec_piping_command(char** argv, int filedes[2]) { 
    // executes specifically for pipes
    pipe(filedes); // to execute pipes, need to use pipe() system call
    int pid = fork(); // fork the parent to create 2 child processes
    if (pid < 0) { 
        cerr << "Fork failed to execute\n"; 
        exit(1);
    }
    else if (pid == 0) { // if successful...
        int newpid = fork(); // fork to create 2 new child processes
        if (newpid < 0) { 
            cerr << "Fork failed to execute\n"; 
            exit(1);
        } 
        else if (newpid == 0) {
            dup2(filedes[1], STDOUT_FILENO); // allocates a new file descriptor that
            // refers to the old file decriptor 
                // in this case, STDOUT_FILENO is the same file descriptor as filedes[1]
            execvp(argv[1], argv);
            close(filedes[1]); // closes the file descriptor
            exit(1);
        }
        else { 
            wait(NULL);
            dup2(filedes[0], STDIN_FILENO); // allocates a new file descriptor that 
            // refers to the old file decriptor 
                // in this case, STDIN_FILENO is the same file descriptor as filedes[0]
            execvp(argv[0], argv);
            close(filedes[0]); // closes the file descriptor
            exit(1);
        }
    }
}

void simple_shell::parse_command(char* cmd, char** cmdTokens) {
    // TODO: tokenize the command string into arguments
    char* tok = strtok(cmd, " \t\n\r\v\f|"); // I added the "|" character, which is needed when piping arguments
    int i = 0;
    while (tok != NULL) {
        cmdTokens[i] = tok;
        i++;
        tok = strtok(NULL, " \t\n\r\v\f|"); // I added the "|" character, which is needed when piping arguments
    }
}

void simple_shell::exec_command(char** argv) {
    // TODO: fork a child process to execute the command.
    // parent process should wait for the child process to complete and reap it
    int pid = fork();
    if (pid < 0) { 
        cerr << "Fork failed to execute\n"; 
        exit(1);
    }
    else if (pid == 0) { execvp(argv[0], argv); }
    else { waitpid(pid, NULL, 0); }
}

bool simple_shell::isQuit(char* cmd) {
    // TODO: check for the command "quit" that terminates the shell
    return strcmp(cmd, (char*)"quit") == 0;
}
